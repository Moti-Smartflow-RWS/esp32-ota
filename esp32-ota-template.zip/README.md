# ESP32 OTA Template

This repository hosts OTA firmware and version information for ESP32 devices.

## Files:
- `firmware_v1.0.1.bin`: Dummy firmware binary
- `version.json`: Contains latest firmware version and download URL

## Usage:
1. Enable GitHub Pages (Settings > Pages > Source: main/root)
2. Use the version.json URL in your ESP32 firmware to check for updates
3. Replace the .bin file with your actual firmware and update version.json accordingly
